# EduTrack - Backend (v2)

This is the EduTrack backend with added features:
- Faculty role
- Swagger API docs at `/api-docs`
- Postman collection included
- Reports export (JSON / CSV)
- Email notifications for grade updates via Gmail SMTP

## Quick start
1. Copy `.env.example` to `.env` and fill DB, JWT and email settings. For Gmail, if you use 2FA, create an App Password and use it as EMAIL_PASS.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run migrations and seeders:
   ```bash
   npx knex migrate:latest
   npx knex seed:run
   ```
4. Start server:
   ```bash
   npm run dev
   ```
5. Open Swagger docs: http://localhost:3000/api-docs
6. Import `EduTrack.postman_collection.json` into Postman to test endpoints.

## Email (Gmail) notes
- Use `EMAIL_USER` and `EMAIL_PASS` in `.env`.
- Gmail may require App Passwords: https://support.google.com/accounts/answer/185833
