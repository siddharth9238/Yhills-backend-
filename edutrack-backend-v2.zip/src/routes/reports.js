const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate, authorize } = require('../middlewares/auth');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const fs = require('fs');
const path = require('path');

// student report
router.get('/student/:id', authenticate, async (req,res,next) => {
  const id = parseInt(req.params.id,10);
  const format = (req.query.format || 'json').toLowerCase();
  try {
    const student = await db('students').where({ id }).first();
    if (!student) return res.status(404).json({ error: 'Student not found' });
    const user = await db('users').where({ id: student.user_id }).first();
    const enrollments = await db('enrollments').where({ student_id: id }).join('courses','enrollments.course_id','courses.id').select('enrollments.*','courses.title as course_title');
    // get grades and attendance for each enrollment
    for (let e of enrollments) {
      e.grades = await db('grades').where({ enrollment_id: e.id }).select('grade','marks','grade_date');
      e.attendance = await db('attendance').where({ enrollment_id: e.id }).select('date','status');
    }
    const report = { student: { id: student.id, name: user.name, email: user.email }, enrollments };
    if (format === 'csv') {
      const rows = [];
      enrollments.forEach(en => {
        en.grades.forEach(g => {
          rows.push({ student: user.name, course: en.course_title, grade: g.grade, marks: g.marks, date: g.grade_date });
        });
      });
      const outPath = path.join('/tmp', `student_${id}_report.csv`);
      const csvWriter = createCsvWriter({
        path: outPath,
        header: [
          {id: 'student', title: 'Student'},
          {id: 'course', title: 'Course'},
          {id: 'grade', title: 'Grade'},
          {id: 'marks', title: 'Marks'},
          {id: 'date', title: 'Date'}
        ]
      });
      await csvWriter.writeRecords(rows);
      res.download(outPath, (err)=>{ if(err) next(err); fs.unlinkSync(outPath); });
    } else {
      res.json({ data: report });
    }
  } catch (err) { next(err); }
});

// course report
router.get('/course/:id', authenticate, async (req,res,next) => {
  const id = parseInt(req.params.id,10);
  const format = (req.query.format || 'json').toLowerCase();
  try {
    const course = await db('courses').where({ id }).first();
    if (!course) return res.status(404).json({ error: 'Course not found' });
    const enrollments = await db('enrollments').where({ course_id: id }).join('students','enrollments.student_id','students.id').join('users','students.user_id','users.id').select('enrollments.id as enrollment_id','students.id as student_id','users.name as student_name');
    for (let e of enrollments) {
      const grades = await db('grades').where({ enrollment_id: e.enrollment_id }).select('grade','marks');
      e.grades = grades;
    }
    const report = { course: { id: course.id, code: course.code, title: course.title }, enrollments };
    if (format === 'csv') {
      const rows = [];
      enrollments.forEach(en => {
        en.grades.forEach(g => {
          rows.push({ course: course.title, student: en.student_name, grade: g.grade, marks: g.marks });
        });
      });
      const outPath = path.join('/tmp', `course_${id}_report.csv`);
      const csvWriter = createCsvWriter({
        path: outPath,
        header: [
          {id: 'course', title: 'Course'},
          {id: 'student', title: 'Student'},
          {id: 'grade', title: 'Grade'},
          {id: 'marks', title: 'Marks'}
        ]
      });
      await csvWriter.writeRecords(rows);
      res.download(outPath, (err)=>{ if(err) next(err); fs.unlinkSync(outPath); });
    } else {
      res.json({ data: report });
    }
  } catch (err) { next(err); }
});

module.exports = router;
