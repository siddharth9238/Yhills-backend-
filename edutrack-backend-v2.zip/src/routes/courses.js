const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate, authorize } = require('../middlewares/auth');
const { sendGradeUpdateEmail } = require('../utils/mailer');

// create course (admin/faculty)
router.post('/', authenticate, authorize(['admin','faculty']), async (req,res,next) => {
  const { code, title, department_id, credits } = req.body;
  try {
    const [id] = await db('courses').insert({ code, title, department_id, credits, faculty_id: req.user.id });
    res.status(201).json({ id });
  } catch (err) {
    next(err);
  }
});

// list courses
router.get('/', authenticate, async (req,res,next) => {
  try {
    const courses = await db('courses').select('*');
    res.json({ data: courses });
  } catch (err) { next(err); }
});

// enroll student in course (admin/faculty)
router.post('/:id/enroll', authenticate, authorize(['admin','faculty']), async (req,res,next) => {
  const courseId = parseInt(req.params.id,10);
  const { student_id, semester } = req.body;
  if (!student_id) return res.status(400).json({ error: 'student_id required' });
  try {
    const [id] = await db('enrollments').insert({ student_id, course_id: courseId, semester });
    res.status(201).json({ id });
  } catch (err) { next(err); }
});

// add grade to enrollment (faculty)
router.post('/enrollments/:id/grades', authenticate, authorize(['faculty','admin']), async (req,res,next) => {
  const enrollmentId = parseInt(req.params.id,10);
  const { grade, marks } = req.body;
  try {
    const [id] = await db('grades').insert({ enrollment_id: enrollmentId, grade, marks, graded_by: req.user.id });
    // fetch necessary info for email
    const enrollment = await db('enrollments').where({ id: enrollmentId }).first();
    const student = await db('students').where({ id: enrollment.student_id }).first();
    const user = await db('users').where({ id: student.user_id }).first();
    const course = await db('courses').where({ id: enrollment.course_id }).first();
    const faculty = await db('users').where({ id: req.user.id }).first();
    // send email (best-effort)
    try {
      await sendGradeUpdateEmail({
        to: user.email,
        studentName: user.name,
        courseTitle: course.title,
        grade,
        marks,
        facultyName: faculty.name
      });
    } catch (mailerErr) {
      console.error('Email send failed', mailerErr);
    }
    res.status(201).json({ id });
  } catch (err) { next(err); }
});

// attendance record
router.post('/enrollments/:id/attendance', authenticate, authorize(['faculty','admin']), async (req,res,next) => {
  const enrollmentId = parseInt(req.params.id,10);
  const { date, status } = req.body;
  try {
    const [id] = await db('attendance').insert({ enrollment_id: enrollmentId, date, status });
    res.status(201).json({ id });
  } catch (err) { next(err); }
});

module.exports = router;
