const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const db = require('../db/knex');
const { hashPassword, comparePassword } = require('../utils/password');

const JWT_SECRET = process.env.JWT_SECRET || 'changeme';

router.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password required' });
  try {
    const hashed = await hashPassword(password);
    const [userId] = await db('users').insert({ name, email, password_hash: hashed, role: role || 'student' });
    if ((role || 'student') === 'student') {
      await db('students').insert({ user_id: userId, roll_no: `R${Date.now()}` });
    }
    res.status(201).json({ id: userId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// separate faculty registration (admin-only typically)
router.post('/register-faculty', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password required' });
  try {
    const hashed = await hashPassword(password);
    const [userId] = await db('users').insert({ name, email, password_hash: hashed, role: 'faculty' });
    res.status(201).json({ id: userId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  try {
    const user = await db('users').where({ email }).first();
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await comparePassword(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
