const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate } = require('../middlewares/auth');

router.get('/:id', authenticate, async (req, res, next) => {
  const id = parseInt(req.params.id,10);
  try {
    const student = await db('students').where('students.id', id)
      .join('users','students.user_id','users.id')
      .select('students.*','users.name','users.email').first();
    if (!student) return res.status(404).json({ error: 'Student not found' });
    res.json({ data: student });
  } catch (err) { next(err); }
});

module.exports = router;
