const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: process.env.EMAIL_PORT ? Number(process.env.EMAIL_PORT) : 465,
  secure: (process.env.EMAIL_SECURE === 'true') || true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

async function sendGradeUpdateEmail({ to, studentName, courseTitle, grade, marks, facultyName }) {
  const from = process.env.EMAIL_FROM || process.env.EMAIL_USER;
  const subject = `Grade updated: ${courseTitle}`;
  const text = `Hi ${studentName},\n\nYour grade for ${courseTitle} was updated to ${grade} (${marks}).\nUpdated by: ${facultyName}\n\nRegards,\nEduTrack`;
  const html = `<p>Hi ${studentName},</p><p>Your grade for <strong>${courseTitle}</strong> was updated to <strong>${grade}</strong> (${marks}).</p><p>Updated by: ${facultyName}</p><p>Regards,<br/>EduTrack</p>`;
  return transporter.sendMail({ from, to, subject, text, html });
}

module.exports = { sendGradeUpdateEmail };
