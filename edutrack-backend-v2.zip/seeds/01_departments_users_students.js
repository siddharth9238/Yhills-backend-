const bcrypt = require('bcrypt');

exports.seed = async function(knex) {
  // Deletes ALL existing entries
  await knex('attendance').del().catch(()=>{});
  await knex('grades').del().catch(()=>{});
  await knex('enrollments').del().catch(()=>{});
  await knex('courses').del().catch(()=>{});
  await knex('students').del().catch(()=>{});
  await knex('users').del().catch(()=>{});
  await knex('departments').del().catch(()=>{});

  const passwordHash = await bcrypt.hash('Password123!', 10);

  const [deptId] = await knex('departments').insert({name: 'Computer Science'});
  const [adminId] = await knex('users').insert({name: 'Admin User', email: 'admin@edutrack.test', password_hash: passwordHash, role: 'admin'});
  const [facultyUserId] = await knex('users').insert({name: 'Dr. Faculty', email: 'faculty@edutrack.test', password_hash: passwordHash, role: 'faculty'});
  const [stuUserId] = await knex('users').insert({name: 'Alice Student', email: 'alice@edutrack.test', password_hash: passwordHash, role: 'student'});
  const [stuId] = await knex('students').insert({user_id: stuUserId, roll_no: 'CS2025-001', dob: '2003-05-12', department_id: deptId});

  const courses = await knex('courses').insert([
    {code: 'CS101', title: 'Introduction to Programming', department_id: deptId, credits: 4, faculty_id: facultyUserId},
    {code: 'CS102', title: 'Data Structures', department_id: deptId, credits: 4, faculty_id: facultyUserId}
  ]);

  // enroll Alice in CS101
  const course = await knex('courses').where({code: 'CS101'}).first();
  await knex('enrollments').insert({student_id: stuId, course_id: course.id, semester: '2025-1'});
};
