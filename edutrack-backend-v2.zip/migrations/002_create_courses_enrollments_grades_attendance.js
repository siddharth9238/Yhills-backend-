exports.up = function(knex) {
  return knex.schema
    .createTable('courses', function(t) {
      t.increments('id').primary();
      t.string('code').notNullable().unique();
      t.string('title').notNullable();
      t.integer('department_id').unsigned().references('id').inTable('departments');
      t.integer('credits').defaultTo(3);
      t.integer('faculty_id').unsigned().references('id').inTable('users');
      t.timestamps(true, true);
    })
    .createTable('enrollments', function(t) {
      t.increments('id').primary();
      t.integer('student_id').unsigned().notNullable().references('id').inTable('students').onDelete('CASCADE');
      t.integer('course_id').unsigned().notNullable().references('id').inTable('courses').onDelete('CASCADE');
      t.string('semester');
      t.timestamp('enrolled_at').defaultTo(knex.fn.now());
      t.unique(['student_id','course_id']);
    })
    .createTable('grades', function(t) {
      t.increments('id').primary();
      t.integer('enrollment_id').unsigned().notNullable().references('id').inTable('enrollments').onDelete('CASCADE');
      t.string('grade');
      t.decimal('marks',5,2);
      t.integer('graded_by').unsigned().references('id').inTable('users');
      t.timestamp('grade_date').defaultTo(knex.fn.now());
    })
    .createTable('attendance', function(t) {
      t.increments('id').primary();
      t.integer('enrollment_id').unsigned().notNullable().references('id').inTable('enrollments').onDelete('CASCADE');
      t.date('date').notNullable();
      t.enu('status', ['present','absent','late']).notNullable();
      t.timestamp('recorded_at').defaultTo(knex.fn.now());
      t.unique(['enrollment_id','date']);
    });
};

exports.down = function(knex) {
  return knex.schema
    .dropTableIfExists('attendance')
    .dropTableIfExists('grades')
    .dropTableIfExists('enrollments')
    .dropTableIfExists('courses');
};
