exports.up = function(knex) {
  return knex.schema
    .createTable('users', function(t) {
      t.increments('id').primary();
      t.string('name').notNullable();
      t.string('email').notNullable().unique();
      t.string('password_hash').notNullable();
      t.enu('role', ['student','faculty','admin']).notNullable().defaultTo('student');
      t.timestamps(true, true);
    })
    .createTable('departments', function(t) {
      t.increments('id').primary();
      t.string('name').notNullable().unique();
    })
    .createTable('students', function(t) {
      t.increments('id').primary();
      t.integer('user_id').unsigned().notNullable().references('id').inTable('users').onDelete('CASCADE');
      t.string('roll_no').notNullable().unique();
      t.date('dob');
      t.integer('department_id').unsigned().references('id').inTable('departments');
      t.timestamps(true, true);
    });
};

exports.down = function(knex) {
  return knex.schema
    .dropTableIfExists('students')
    .dropTableIfExists('departments')
    .dropTableIfExists('users');
};
