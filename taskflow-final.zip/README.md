# TaskFlow - Final Deliverable

This repository contains a complete TaskFlow backend implementation aligned to the problem statement.
Run with Docker Compose (MySQL + App) or locally with a MySQL instance.

Quickstart (Docker):
1. Copy `.env.example` to `.env` and fill required values.
2. Run `docker compose up --build`.
3. Swagger: http://localhost:4000/api-docs
4. Postman: import TaskFlow.postman_collection.json
