const bcrypt = require('bcrypt');
exports.seed = async function(knex) {
  // clean
  await knex('activity_logs').del().catch(()=>{});
  await knex('time_entries').del().catch(()=>{});
  await knex('attachments').del().catch(()=>{});
  await knex('comments').del().catch(()=>{});
  await knex('task_dependencies').del().catch(()=>{});
  await knex('task_assignees').del().catch(()=>{});
  await knex('tasks').del().catch(()=>{});
  await knex('projects').del().catch(()=>{});
  await knex('team_members').del().catch(()=>{});
  await knex('teams').del().catch(()=>{});
  await knex('users').del().catch(()=>{});

  const pass = await bcrypt.hash('Password123!', 10);
  const [adminId] = await knex('users').insert({name:'Admin User', email:'admin@taskflow.test', password_hash:pass, role:'admin'});
  const [managerId] = await knex('users').insert({name:'Manager One', email:'manager@taskflow.test', password_hash:pass, role:'manager'});
  const [memberId] = await knex('users').insert({name:'Member One', email:'member@taskflow.test', password_hash:pass, role:'member'});

  const [teamId] = await knex('teams').insert({name:'Alpha Team', description:'Core dev team'});
  await knex('team_members').insert({team_id: teamId, user_id: managerId, role_in_team: 'lead'});
  await knex('team_members').insert({team_id: teamId, user_id: memberId, role_in_team: 'developer'});

  const [projId] = await knex('projects').insert({name:'Project Phoenix', description:'Top secret', owner_team_id: teamId});
  const [taskId] = await knex('tasks').insert({project_id: projId, title:'Setup repo', description:'Initialize git repo', created_by: managerId, status:'todo', priority:'high'});
  await knex('task_assignees').insert({task_id: taskId, user_id: memberId});
  await knex('time_entries').insert({task_id: taskId, user_id: memberId, hours: 1.5, description: 'Initial setup'});
};
