exports.up = function(knex) {
  return knex.schema
    .createTable('tasks', function(t) {
      t.increments('id').primary();
      t.integer('project_id').unsigned().notNullable().references('id').inTable('projects').onDelete('CASCADE');
      t.string('title').notNullable().index();
      t.text('description');
      t.enu('status',['todo','in_progress','review','done']).defaultTo('todo').index();
      t.enu('priority',['low','medium','high','urgent']).defaultTo('medium').index();
      t.decimal('estimate_hours',6,2);
      t.integer('created_by').unsigned().references('id').inTable('users');
      t.date('due_date');
      t.timestamps(true,true);
    })
    .createTable('task_assignees', function(t) {
      t.increments('id').primary();
      t.integer('task_id').unsigned().notNullable().references('id').inTable('tasks').onDelete('CASCADE');
      t.integer('user_id').unsigned().notNullable().references('id').inTable('users').onDelete('CASCADE');
      t.unique(['task_id','user_id']);
    })
    .createTable('task_dependencies', function(t) {
      t.increments('id').primary();
      t.integer('task_id').unsigned().notNullable().references('id').inTable('tasks').onDelete('CASCADE');
      t.integer('depends_on_task_id').unsigned().notNullable().references('id').inTable('tasks').onDelete('CASCADE');
      t.unique(['task_id','depends_on_task_id']);
    })
    .createTable('comments', function(t) {
      t.increments('id').primary();
      t.integer('task_id').unsigned().notNullable().references('id').inTable('tasks').onDelete('CASCADE');
      t.integer('user_id').unsigned().notNullable().references('id').inTable('users');
      t.text('body').notNullable();
      t.integer('parent_comment_id').unsigned().references('id').inTable('comments');
      t.timestamps(true,true);
    })
    .createTable('attachments', function(t) {
      t.increments('id').primary();
      t.integer('task_id').unsigned().notNullable().references('id').inTable('tasks').onDelete('CASCADE');
      t.integer('uploader_id').unsigned().notNullable().references('id').inTable('users');
      t.string('filename');
      t.string('path');
      t.string('mime');
      t.timestamps(true,true);
    })
    .createTable('time_entries', function(t) {
      t.increments('id').primary();
      t.integer('task_id').unsigned().references('id').inTable('tasks').onDelete('CASCADE');
      t.integer('user_id').unsigned().references('id').inTable('users');
      t.decimal('hours',6,2).notNullable();
      t.text('description');
      t.timestamp('created_at').defaultTo(knex.fn.now());
    })
    .createTable('activity_logs', function(t) {
      t.increments('id').primary();
      t.integer('user_id').unsigned().references('id').inTable('users');
      t.string('entity');
      t.integer('entity_id');
      t.string('action');
      t.json('payload');
      t.timestamp('created_at').defaultTo(knex.fn.now());
    });
};

exports.down = function(knex) {
  return knex.schema
    .dropTableIfExists('activity_logs')
    .dropTableIfExists('time_entries')
    .dropTableIfExists('attachments')
    .dropTableIfExists('comments')
    .dropTableIfExists('task_dependencies')
    .dropTableIfExists('task_assignees')
    .dropTableIfExists('tasks');
};
