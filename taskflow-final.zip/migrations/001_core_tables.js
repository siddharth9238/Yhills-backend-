exports.up = function(knex) {
  return knex.schema
    .createTable('users', function(t) {
      t.increments('id').primary();
      t.string('name').notNullable().index();
      t.string('email').notNullable().unique().index();
      t.string('password_hash').notNullable();
      t.enu('role', ['admin','manager','member']).notNullable().defaultTo('member').index();
      t.timestamps(true,true);
    })
    .createTable('teams', function(t) {
      t.increments('id').primary();
      t.string('name').notNullable().index();
      t.text('description');
      t.timestamps(true,true);
    })
    .createTable('team_members', function(t) {
      t.increments('id').primary();
      t.integer('team_id').unsigned().notNullable().references('id').inTable('teams').onDelete('CASCADE');
      t.integer('user_id').unsigned().notNullable().references('id').inTable('users').onDelete('CASCADE');
      t.string('role_in_team');
      t.unique(['team_id','user_id']);
      t.timestamps(true,true);
    })
    .createTable('projects', function(t) {
      t.increments('id').primary();
      t.string('name').notNullable().index();
      t.text('description');
      t.integer('owner_team_id').unsigned().references('id').inTable('teams');
      t.integer('parent_project_id').unsigned().references('id').inTable('projects');
      t.date('start_date');
      t.date('end_date');
      t.timestamps(true,true);
    });
};

exports.down = function(knex) {
  return knex.schema
    .dropTableIfExists('projects')
    .dropTableIfExists('team_members')
    .dropTableIfExists('teams')
    .dropTableIfExists('users');
};
