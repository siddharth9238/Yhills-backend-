/**
 * @swagger
 * tags:
 *   name: Comments
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate } = require('../middlewares/auth');
const { body, validationResult } = require('express-validator');
const { sendMail } = require('../utils/mailer');

router.post('/', authenticate, [
  body('task_id').isInt(),
  body('body').isString().notEmpty()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const { task_id, body: text, parent_comment_id } = req.body;
    const [id] = await db('comments').insert({ task_id, user_id: req.user.id, body: text, parent_comment_id });
    const assignees = await db('task_assignees').where({ task_id }).join('users','task_assignees.user_id','users.id').select('users.email');
    for(const a of assignees){ if(a.email) await sendMail({ to: a.email, subject: 'New Comment', text: `New comment on task ${task_id}: ${text}` }).catch(()=>{}); }
    await db('activity_logs').insert({ user_id: req.user.id, entity: 'comment', entity_id: id, action: 'created', payload: JSON.stringify({ task_id }) });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

module.exports = router;
