/**
 * @swagger
 * tags:
 *   name: Projects
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate, authorize } = require('../middlewares/auth');
const { body, validationResult } = require('express-validator');

router.post('/', authenticate, authorize(['admin','manager']), [
  body('name').isString().notEmpty()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const { name, description, owner_team_id, parent_project_id, start_date, end_date } = req.body;
    const [id] = await db('projects').insert({ name, description, owner_team_id, parent_project_id, start_date, end_date });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

router.get('/:id', authenticate, async (req,res,next)=>{
  try{
    const id = parseInt(req.params.id,10);
    const project = await db('projects').where({ id }).first();
    if(!project) return res.status(404).json({ error:'Not found' });
    res.json({ data: project });
  }catch(err){ next(err); }
});

module.exports = router;
