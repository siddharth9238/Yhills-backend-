/**
 * @swagger
 * tags:
 *   name: Auth
 * /api/v1/auth/register:
 *   post:
 *     summary: Register a user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name: { type: string }
 *               email: { type: string }
 *               password: { type: string }
 *               role: { type: string }
 *     responses:
 *       201: { description: Created }
 */
/**
 * @swagger
 * /api/v1/auth/login:
 *   post:
 *     summary: Login
 *     tags: [Auth]
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const jwt = require('jsonwebtoken');
const { hashPassword, comparePassword } = require('../utils/password');
const { body, validationResult } = require('express-validator');
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

router.post('/register', [
  body('name').isString().notEmpty(),
  body('email').isEmail(),
  body('password').isLength({ min: 8 })
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { name,email,password,role } = req.body;
  try{
    const hashed = await hashPassword(password);
    const [id] = await db('users').insert({ name, email, password_hash: hashed, role: role || 'member' });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

router.post('/login', [
  body('email').isEmail(),
  body('password').isString().notEmpty()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { email,password } = req.body;
  try{
    const user = await db('users').where({ email }).first();
    if(!user) return res.status(401).json({ error:'Invalid credentials' });
    const ok = await comparePassword(password, user.password_hash);
    if(!ok) return res.status(401).json({ error:'Invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ token });
  }catch(err){ next(err); }
});

module.exports = router;
