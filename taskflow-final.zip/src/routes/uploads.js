/**
 * @swagger
 * tags:
 *   name: Uploads
 */
const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const db = require('../db/knex');
const { authenticate } = require('../middlewares/auth');

const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR,{ recursive:true });

const storage = multer.diskStorage({
  destination: (req,file,cb)=> cb(null, UPLOAD_DIR),
  filename: (req,file,cb)=> cb(null, Date.now()+'-'+file.originalname)
});
const upload = multer({ storage });

router.post('/task/:id', authenticate, upload.single('file'), async (req,res,next)=>{
  try{
    const taskId = parseInt(req.params.id,10);
    const file = req.file;
    if(!file) return res.status(400).json({ error:'file required' });
    const [id] = await db('attachments').insert({ task_id: taskId, uploader_id: req.user.id, filename: file.originalname, path: file.path, mime: file.mimetype });
    await db('activity_logs').insert({ user_id: req.user.id, entity: 'attachment', entity_id: id, action: 'uploaded', payload: JSON.stringify({ filename: file.originalname }) });
    res.status(201).json({ id, filename: file.originalname, path: file.path });
  }catch(err){ next(err); }
});

module.exports = router;
