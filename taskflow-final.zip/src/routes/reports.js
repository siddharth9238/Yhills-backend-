/**
 * @swagger
 * tags:
 *   name: Reports
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const fs = require('fs');
const path = require('path');
const { authenticate } = require('../middlewares/auth');

router.get('/project/:id/progress', authenticate, async (req,res,next)=>{
  try{
    const id = parseInt(req.params.id,10);
    const total = await db('tasks').where({ project_id: id }).count('* as cnt').first();
    const done = await db('tasks').where({ project_id: id, status: 'done' }).count('* as cnt').first();
    const percent = total.cnt == 0 ? 0 : Math.round((done.cnt/total.cnt)*100);
    res.json({ data: { total: total.cnt, done: done.cnt, percent } });
  }catch(err){ next(err); }
});

router.get('/project/:id/burndown', authenticate, async (req,res,next)=>{
  try{
    const id = parseInt(req.params.id,10);
    const rows = await db('tasks').where({ project_id: id }).select('status','created_at','updated_at');
    const summary = rows.reduce((acc,r)=>{ acc[r.status]=(acc[r.status]||0)+1; return acc; },{});
    res.json({ data: summary });
  }catch(err){ next(err); }
});

router.get('/activity/export', authenticate, async (req,res,next)=>{
  try{
    const rows = await db('activity_logs').join('users','activity_logs.user_id','users.id').select('activity_logs.*','users.name as user_name');
    const outPath = path.join('/tmp', `activity_export.csv`);
    const csvWriter = createCsvWriter({ path: outPath, header: [
      {id:'created_at', title:'Date'},{id:'user_name', title:'User'},{id:'entity', title:'Entity'},{id:'action', title:'Action'},{id:'payload', title:'Payload'}
    ]});
    await csvWriter.writeRecords(rows.map(r=>({ created_at: r.created_at, user_name: r.user_name, entity: r.entity, action: r.action, payload: JSON.stringify(r.payload)})));
    res.download(outPath, (err)=>{ if(err) next(err); fs.unlinkSync(outPath); });
  }catch(err){ next(err); }
});

module.exports = router;
