/**
 * @swagger
 * tags:
 *   name: Tasks
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate, authorize } = require('../middlewares/auth');
const { body, validationResult } = require('express-validator');
const { sendMail } = require('../utils/mailer');

router.post('/', authenticate, authorize(['admin','manager']), [
  body('project_id').isInt(),
  body('title').isString().notEmpty()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const { project_id, title, description, priority, estimate_hours, due_date, assignees, dependencies } = req.body;
    const [taskId] = await db('tasks').insert({ project_id, title, description, priority, estimate_hours, due_date, created_by: req.user.id });
    if(Array.isArray(assignees)){
      for(const userId of assignees){
        await db('task_assignees').insert({ task_id: taskId, user_id: userId }).catch(()=>{});
        try {
          const u = await db('users').where({ id: userId }).first();
          if(u && u.email) await sendMail({ to: u.email, subject: 'New Task Assigned', text: `You have been assigned task: ${title}` });
        } catch(e){ console.error('mail fail', e); }
      }
    }
    if(Array.isArray(dependencies)){
      for(const depId of dependencies) await db('task_dependencies').insert({ task_id: taskId, depends_on_task_id: depId }).catch(()=>{});
    }
    await db('activity_logs').insert({ user_id: req.user.id, entity: 'task', entity_id: taskId, action: 'created', payload: JSON.stringify({ title }) });
    res.status(201).json({ id: taskId });
  }catch(err){ next(err); }
});

router.get('/:id', authenticate, async (req,res,next)=>{
  try{
    const id = parseInt(req.params.id,10);
    const task = await db('tasks').where({ id }).first();
    if(!task) return res.status(404).json({ error:'Task not found' });
    const assignees = await db('task_assignees').where({ task_id: id }).join('users','task_assignees.user_id','users.id').select('users.id','users.name','users.email');
    const deps = await db('task_dependencies').where({ task_id: id }).select('depends_on_task_id');
    const comments = await db('comments').where({ task_id: id }).join('users','comments.user_id','users.id').select('comments.*','users.name as author');
    res.json({ data: Object.assign(task, { assignees, deps, comments }) });
  }catch(err){ next(err); }
});

router.post('/:id/time', authenticate, [
  body('hours').isFloat({ gt: 0 })
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const taskId = parseInt(req.params.id,10);
    const { hours, description } = req.body;
    const [id] = await db('time_entries').insert({ task_id: taskId, user_id: req.user.id, hours, description });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

module.exports = router;
