/**
 * @swagger
 * tags:
 *   name: Teams
 */
const express = require('express');
const router = express.Router();
const db = require('../db/knex');
const { authenticate, authorize } = require('../middlewares/auth');
const { body, validationResult } = require('express-validator');

router.post('/', authenticate, authorize(['admin','manager']), [
  body('name').isString().notEmpty()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const { name, description } = req.body;
    const [id] = await db('teams').insert({ name, description });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

router.get('/', authenticate, async (req,res,next)=>{
  try{
    const teams = await db('teams').select('*');
    res.json({ data: teams });
  }catch(err){ next(err); }
});

router.post('/:id/members', authenticate, authorize(['admin','manager']), [
  body('user_id').isInt()
], async (req,res,next)=>{
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try{
    const teamId = parseInt(req.params.id,10);
    const { user_id, role_in_team } = req.body;
    const [id] = await db('team_members').insert({ team_id: teamId, user_id, role_in_team });
    res.status(201).json({ id });
  }catch(err){ next(err); }
});

module.exports = router;
