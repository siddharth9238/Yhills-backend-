require('dotenv').config();
const express = require('express');
const http = require('http');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const socketio = require('socket.io');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./docs/swagger');

const rateLimit = require('./middlewares/rateLimit');
const authRoutes = require('./routes/auth');
const teamRoutes = require('./routes/teams');
const projectRoutes = require('./routes/projects');
const taskRoutes = require('./routes/tasks');
const commentRoutes = require('./routes/comments');
const uploadRoutes = require('./routes/uploads');
const reportRoutes = require('./routes/reports');

const { errorHandler } = require('./middlewares/errors');

const app = express();
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());
app.use('/uploads', express.static('uploads'));
app.use(rateLimit);

app.get('/health', (req,res) => res.json({ status: 'ok' }));
app.get('/', (req,res)=> res.send('TaskFlow API root'));

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/teams', teamRoutes);
app.use('/api/v1/projects', projectRoutes);
app.use('/api/v1/tasks', taskRoutes);
app.use('/api/v1/comments', commentRoutes);
app.use('/api/v1/uploads', uploadRoutes);
app.use('/api/v1/reports', reportRoutes);

app.use(errorHandler);

const server = http.createServer(app);
const io = socketio(server, { cors: { origin: '*' } });
require('./sockets')(io);

const PORT = process.env.PORT || 4000;
server.listen(PORT, ()=> console.log(`Server running on port ${PORT}`));
