module.exports = function(io){ 
  io.on('connection', socket=>{
    console.log('socket connected', socket.id);
    socket.on('joinProject', (projectId)=> socket.join('project_'+projectId));
    socket.on('leaveProject', (projectId)=> socket.leave('project_'+projectId));
    socket.on('taskUpdated', payload => {
      io.to('project_'+payload.projectId).emit('taskUpdated', payload);
    });
  });
};
