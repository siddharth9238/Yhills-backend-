const { RateLimiterMemory } = require('rate-limiter-flexible');
const points = Number(process.env.RATE_LIMIT_POINTS || 100);
const duration = Number(process.env.RATE_LIMIT_DURATION || 60);
const rl = new RateLimiterMemory({ points, duration });
module.exports = (req,res,next)=>{
  rl.consume(req.ip).then(()=> next()).catch(()=> res.status(429).json({ error: 'Too Many Requests' }));
};
