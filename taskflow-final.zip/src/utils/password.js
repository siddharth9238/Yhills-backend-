const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;
async function hashPassword(p){ return bcrypt.hash(p, SALT_ROUNDS); }
async function comparePassword(p,h){ return bcrypt.compare(p,h); }
module.exports = { hashPassword, comparePassword };
