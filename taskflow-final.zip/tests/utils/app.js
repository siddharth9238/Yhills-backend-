const express = require('express');
require('dotenv').config();
const app = express();
app.use(express.json());
app.use('/api/v1/auth', require('../../src/routes/auth'));
app.use('/api/v1/tasks', require('../../src/routes/tasks'));
module.exports = app;
