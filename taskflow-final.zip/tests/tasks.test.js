const request = require('supertest');
const app = require('./utils/app');
describe('Tasks', ()=> {
  it('creates a task without auth should fail', async ()=> {
    const res = await request(app).post('/api/v1/tasks').send({ project_id:1, title:'Test Task' });
    expect(res.statusCode).toBe(401);
  }, 20000);
});
