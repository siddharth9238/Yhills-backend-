const request = require('supertest');
const app = require('./utils/app');
describe('Auth', ()=> {
  it('registers and logs in a user', async ()=> {
    const name = 'Test User';
    const email = 'testuser@example.com';
    const pw = 'Password123!';
    const res = await request(app).post('/api/v1/auth/register').send({ name, email, password: pw });
    expect(res.statusCode).toBe(201);
    const login = await request(app).post('/api/v1/auth/login').send({ email, password: pw });
    expect(login.statusCode).toBe(200);
    expect(login.body.token).toBeDefined();
  }, 20000);
});
