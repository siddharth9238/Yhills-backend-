const express=require('express'); const r=express.Router(); r.get('/', (req,res)=>res.send('auth')); module.exports=r;
